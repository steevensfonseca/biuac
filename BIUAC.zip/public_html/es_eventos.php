<?php
session_start();
// Asegúrate de incluir la librería phpqrcode
include('QR\phpqrcode\phpqrcode.php');


session_start();

// Verificar si el usuario está autenticado como estudiante
if (!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true) {
    header('Location: login.html');
    exit();
}


// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

// Obtener eventos
$sql = "SELECT * FROM eventos";
$result = $enlace->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin de eventos</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    

    <!-- Fonts -->

    <!-- Open Sans for body font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700,800" rel="stylesheet">
	<!-- Montserrat for title -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
 
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Bootstrap CSS -->
    <!-- Bootstrap CSS and JS -->
  </head>
<body>
  	<!-- Start Header -->
	  <header id="mu-hero" class="" role="banner">
		<!-- Start menu  -->
		<nav class="navbar navbar-fixed-top navbar-default mu-navbar">
		  	<div class="container">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>

			      <!-- Logo -->
			      <a class="navbar-brand" href="index.html">BIUAC</a>

			    </div>

			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      	<ul class="nav navbar-nav mu-menu navbar-right">
			      		<li><a href="index.html">Home</a></li>
				        <li><a href="index.html">Sobre nosotros</a></li>
			            <li><a href="index.html">Ponentes</a></li>
			            <li><a href="index.html">Registro</a></li>
						<li><a href="login.html">Login</a></li>         
			            <li><a href="index.html">Contacto</a></li>
			      	</ul>
			    </div><!-- /.navbar-collapse -->
		  	</div><!-- /.container-fluid -->
		</nav>
		<!-- End menu -->

		<div class="mu-hero-overlay">
			<div class="container">
				<div class="mu-hero-area">

					<!-- Start hero featured area -->
					<div class="mu-hero-featured-area">
						<!-- Start center Logo -->
						<div class="mu-logo-area">
							<!-- text based logo -->
							<a class="mu-logo" href="#">BIUAC</a>
							<!-- image based logo -->
							<!-- <a class="mu-logo" href="#"><img src="assets/images/logo.jpg" alt="logo img"></a> -->
						</div>
						<!-- End center Logo -->

						<div class="mu-hero-featured-content">

							<h1>Hola!! asiste a todos los eventos</h1>
							<h2>Conoce todos los eventos que la Universidad Atunoma tiene para ti</h2>
							<p class="mu-event-date-line">2024. Barranquilla, Colombia</p>

							<div class="mu-event-counter-area">
								<div id="mu-event-counter">
									
								</div>
							</div>

						</div>
					</div>
					<!-- End hero featured area -->

				</div>
			</div>
		</div>
	</header>
	<!-- End Header -->
<body>
    <div class="container">
        <h1>Eventos Disponibles</h1>
<!-- Barra de búsqueda -->
<input type="text" id="searchInput" class="search-bar" placeholder="Buscar eventos...">
<style>
    .search-bar {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 16px;
    }

    .search-bar:focus {
        border-color: #007bff;
        outline: none;
    }
</style>

<br>
        <!-- Botón de Cerrar Sesión -->
        <div class="text-right mb-3">
        <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
    </div>
    <br>
<!-- Tabla de eventos -->
<table class="table table-bordered" id="eventsTable">
    <thead>
        <tr>
            <th>Título</th>
            <th>Lugar</th>
            <th>Pensado para</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Descripción</th>
            <th>Modalidad</th>
            <th>Confirmar Asistencia</th>
            <th>Generar QR</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['titulo']); ?></td>
            <td><?php echo htmlspecialchars($row['lugar']); ?></td>
            <td><?php echo htmlspecialchars($row['para']); ?></td>
            <td><?php echo htmlspecialchars($row['fecha']); ?></td>
            <td><?php echo htmlspecialchars($row['hora']); ?></td>
            <td><?php echo htmlspecialchars($row['descripcion']); ?></td>
            <td><?php echo htmlspecialchars($row['modalidad']); ?></td>
            <td>
                <form method="POST" action="confirmar_asistencia.php">
                    <input type="hidden" name="id_evento" value="<?php echo $row['id']; ?>">
                    <button type="submit" class="btn btn-primary">Confirmar Asistencia</button>
                </form>
            </td>
            <td>
                <!-- Botón para generar el QR -->
                <button class="btn btn-secondary generarQR" data-id="<?php echo $row['id']; ?>">Generar QR</button>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>



<!-- Modal personalizado -->
<div id="qrModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Código QR</h2>
        <div id="qrContainer" class="qr-container">
            <!-- El QR generado aparecerá aquí -->
        </div>
    </div>
</div>

<!-- Estilos para el modal -->
<style>
    .modal {
        display: none; 
        position: fixed; 
        z-index: 1; 
        left: 0;
        top: 0;
        width: 100%; 
        height: 100%; 
        overflow: auto; 
        background-color: rgb(0,0,0); 
        background-color: rgba(0,0,0,0.4); 
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto; 
        padding: 20px;
        border: 1px solid #888;
        width: 80%; 
        max-width: 500px; 
        text-align: center;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    .qr-container img {
        width: 100%;
        height: auto;
    }
</style>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $('.generarQR').click(function () {
            $.ajax({
                type: "POST",
                url: "generar_qr.php", // Reemplaza con la ruta a tu script PHP
                data: { url: "https://biuac.000webhostapp.com/login.html" },
                success: function (response) {
                    // Mostrar el QR generado en el modal
                    $('#qrContainer').html(response);
                    // Abrir el modal
                    $('#qrModal').css('display', 'block');
                },
                error: function () {
                    alert('Error al generar el código QR');
                }
            });
        });

        // Cerrar el modal cuando se hace clic en el botón de cerrar
        $('.close').click(function () {
            $('#qrModal').css('display', 'none');
        });

        // Cerrar el modal cuando se hace clic fuera del contenido del modal
        $(window).click(function (event) {
            if (event.target.id === 'qrModal') {
                $('#qrModal').css('display', 'none');
            }
        });
    });
</script>

<script>
    document.getElementById('searchInput').addEventListener('keyup', function() {
        var input, filter, table, tr, td, i, j, txtValue;
        input = document.getElementById('searchInput');
        filter = input.value.toLowerCase();
        table = document.getElementById('eventsTable');
        tr = table.getElementsByTagName('tr');

        for (i = 1; i < tr.length; i++) {
            tr[i].style.display = 'none';
            td = tr[i].getElementsByTagName('td');
            for (j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;
                    if (txtValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = '';
                        break;
                    }
                }
            }
        }
    });
</script>



	
	<!-- Start footer -->
	<footer id="mu-footer" role="contentinfo">
		<div class="container">
			<div class="mu-footer-area">
				<div class="mu-footer-top">
					<div class="mu-social-media">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-youtube"></i></a>
					</div>
				</div>
				<div class="mu-footer-bottom">
					<p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="https://www.uac.edu.co/bienestar-institucional/">Bienestar institucional UAC</a>. All right reserved.</p>
				</div>
			</div>
		</div>

</footer>
<!-- End footer -->

    
<!-- jQuery library -->
<!-- Incluimos jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!-- Bootstrap -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Slick slider -->
<script type="text/javascript" src="assets/js/slick.min.js"></script>
<!-- Event Counter -->
<script type="text/javascript" src="assets/js/jquery.countdown.min.js"></script>
<!-- Ajax contact form  -->
<script type="text/javascript" src="assets/js/app.js"></script>

   

<!-- Custom js -->
<script type="text/javascript" src="assets/js/custom.js"></script>

<!-- Tempus Dominus Bootstrap 4 CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/css/tempusdominus-bootstrap-4.min.css" />

<!-- Tempus Dominus Bootstrap 4 JS and dependencies -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>


<!-- Template Javascript -->
<script src="js/main.js"></script>


</body>
</html>


<?php
$enlace->close();
?>
