<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

// Consulta para obtener los datos de la tabla "eventos"
$sql = "SELECT id, titulo, lugar, fecha, hora, descripcion, modalidad FROM eventos";
$result = $enlace->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin de eventos</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    

    <!-- Fonts -->

    <!-- Open Sans for body font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700,800" rel="stylesheet">
	<!-- Montserrat for title -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
 
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Bootstrap CSS -->
  </head>
<body>
  	<!-- Start Header -->
	  <header id="mu-hero" class="" role="banner">
		<!-- Start menu  -->
		<nav class="navbar navbar-fixed-top navbar-default mu-navbar">
		  	<div class="container">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>

			      <!-- Logo -->
			      <a class="navbar-brand" href="index.html">BIUAC</a>

			    </div>

			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      	<ul class="nav navbar-nav mu-menu navbar-right">
			      		<li><a href="index.html">Home</a></li>
				        <li><a href="index.html">Sobre nosotros</a></li>
			            <li><a href="index.html">Ponentes</a></li>
			            <li><a href="index.html">Registro</a></li>
						<li><a href="login.html">Login</a></li>         
			            <li><a href="index.html">Contacto</a></li>
			      	</ul>
			    </div><!-- /.navbar-collapse -->
		  	</div><!-- /.container-fluid -->
		</nav>
		<!-- End menu -->

		<div class="mu-hero-overlay">
			<div class="container">
				<div class="mu-hero-area">

					<!-- Start hero featured area -->
					<div class="mu-hero-featured-area">
						<!-- Start center Logo -->
						<div class="mu-logo-area">
							<!-- text based logo -->
							<a class="mu-logo" href="#">BIUAC</a>
							<!-- image based logo -->
							<!-- <a class="mu-logo" href="#"><img src="assets/images/logo.jpg" alt="logo img"></a> -->
						</div>
						<!-- End center Logo -->

						<div class="mu-hero-featured-content">

							<h1>Hola!! Administra todos los eventos</h1>
							<h2>Conoce todos los eventos que la Universidad Atunoma tiene para ti</h2>
							<p class="mu-event-date-line">2024. Barranquilla, Colombia</p>

							<div class="mu-event-counter-area">
								<div id="mu-event-counter">
									
								</div>
							</div>

						</div>
					</div>
					<!-- End hero featured area -->

				</div>
			</div>
		</div>
	</header>
	<!-- End Header -->
    <div class="mu-title-area">
        <h2 class="mu-title">Bienvenido al gestor de eventos</h2>
        <p>Aqui podras navegar pos los distintos eventos existentes y ademas editar o eliminar los que desees.</p>
    </div>
    <div class="container mt-5">
    <h2 class="text-center">Administrar Eventos</h2>
        <!-- Botón de Cerrar Sesión -->
        <div class="text-right mb-3">
        <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
    </div>
    <br>
    <!-- Barra de búsqueda -->
<div class="row">
    <div class="col-md-12">
        <input type="text" id="searchInput" class="search-bar" placeholder="Buscar eventos...">
    </div>
</div>
<style>
    .search-bar {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 16px;
    }

    .search-bar:focus {
        border-color: #007bff;
        outline: none;
    }
</style>
<br>
    <div class="table-responsive">
    <table id="eventTable" class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Lugar</th>
            <th>Pensado para</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Descripción</th>
            <th>Modalidad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody id="eventTableBody">
        <?php
        // PHP para mostrar la tabla inicial (sin filtro)
        // Conexión a la base de datos
        $enlace = new mysqli($servername, $username, $password, $dbname);
        if ($enlace->connect_error) {
            die("Database connection error: " . $enlace->connect_error);
        }

        // Obtener todos los eventos
        $sql = "SELECT * FROM eventos";
        $result = $enlace->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['titulo']}</td>
                        <td>{$row['lugar']}</td>
                        <td>{$row['para']}</td>
                        <td>{$row['fecha']}</td>
                        <td>{$row['hora']}</td>
                        <td>{$row['descripcion']}</td>
                        <td>{$row['modalidad']}</td>
                        <td>
                            <a href='editar_evento.php?id={$row['id']}' class='btn btn-warning btn-sm'>Editar</a>
                            <a href='eliminar_evento.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este evento?\")'>Eliminar</a>
                            <a href='ver_asistentes.php?id={$row['id']}' class='btn btn-info btn-sm'>Ver asistentes</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='8'>No hay eventos disponibles</td></tr>";
        }

        $enlace->close();
        ?>
    </tbody>
</table>
<script>
document.getElementById("searchInput").addEventListener("input", function() {
    let input = this.value.toLowerCase();
    let table = document.getElementById("eventTable");
    let tbody = document.getElementById("eventTableBody");
    let rows = tbody.getElementsByTagName("tr");

    // Iterar sobre todas las filas de la tabla
    for (let i = 0; i < rows.length; i++) {
        let display = false;
        let cells = rows[i].getElementsByTagName("td");

        // Iterar sobre todas las celdas de la fila
        for (let j = 0; j < cells.length; j++) {
            let cell = cells[j];
            if (cell) {
                let textValue = cell.textContent || cell.innerText;
                if (textValue.toLowerCase().indexOf(input) > -1) {
                    display = true;
                    break; // Mostrar la fila si se encontró una coincidencia
                }
            }
        }

        // Mostrar u ocultar la fila según el resultado de la búsqueda
        if (display) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
});
</script>
	<!-- Start footer -->
	<footer id="mu-footer" role="contentinfo">
		<div class="container">
			<div class="mu-footer-area">
				<div class="mu-footer-top">
					<div class="mu-social-media">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-youtube"></i></a>
					</div>
				</div>
				<div class="mu-footer-bottom">
					<p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="https://www.uac.edu.co/bienestar-institucional/">Bienestar institucional UAC</a>. All right reserved.</p>
				</div>
			</div>
		</div>
	</div>
</div>
</footer>
<!-- End footer -->

    
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!-- Bootstrap -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Slick slider -->
<script type="text/javascript" src="assets/js/slick.min.js"></script>
<!-- Event Counter -->
<script type="text/javascript" src="assets/js/jquery.countdown.min.js"></script>
<!-- Ajax contact form  -->
<script type="text/javascript" src="assets/js/app.js"></script>

   

<!-- Custom js -->
<script type="text/javascript" src="assets/js/custom.js"></script>

<!-- Tempus Dominus Bootstrap 4 CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/css/tempusdominus-bootstrap-4.min.css" />

<!-- Tempus Dominus Bootstrap 4 JS and dependencies -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>


<!-- Template Javascript -->
<script src="js/main.js"></script>

</body>
</html>
