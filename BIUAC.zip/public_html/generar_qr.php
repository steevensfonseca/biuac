<?php
// Agregamos la librería para generar códigos QR
require "QR/phpqrcode/qrlib.php";    

// Declaramos una carpeta temporal para guardar las imágenes generadas
$dir = 'qrcodes/';

// Si no existe la carpeta, la creamos
if (!file_exists($dir)) {
    mkdir($dir);
}

// Obtener la URL desde la petición AJAX
if (isset($_POST['url'])) {
    $url = $_POST['url'];
    
    // Declaramos la ruta y nombre del archivo a generar
    $filename = $dir . 'qr_login.png';

    // Parámetros de Configuración
    $tamaño = 10; // Tamaño de Pixel
    $level = 'L'; // Precisión Baja
    $framSize = 3; // Tamaño en blanco

    // Enviamos los parámetros a la función para generar código QR 
    QRcode::png($url, $filename, $level, $tamaño, $framSize); 

    // Mostramos la imagen generada
    echo '<img src="'.$dir.basename($filename).'" class="img-fluid" /><hr/>';  
}
?>
