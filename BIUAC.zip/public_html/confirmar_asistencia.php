<?php
session_start();

// Verifica si el estudiante ha iniciado sesión
if (!isset($_SESSION['cedulaEstudiante'])) {
    echo "<script>alert('Debe iniciar sesión primero.'); window.location.href='login.html';</script>";
    exit();
}

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

// Obtener ID del evento y cédula del estudiante
$id_evento = $_POST['id_evento'];
$cedulaEstudiante = $_SESSION['cedulaEstudiante'];

// Obtener el ID del estudiante
$sql = "SELECT id_estudiante FROM estudiantes WHERE cedula = ?";
$stmt = $enlace->prepare($sql);
$stmt->bind_param("i", $cedulaEstudiante);
$stmt->execute();
$stmt->bind_result($id_estudiante);
$stmt->fetch();
$stmt->close();

if ($id_estudiante) {
    // Insertar registro en la tabla `asistencia`
    $insertar = "INSERT INTO asistencia (id_estudiante_asistencia, id_evento) VALUES (?, ?)";
    $stmt = $enlace->prepare($insertar);
    $stmt->bind_param("ii", $id_estudiante, $id_evento);
    
    if ($stmt->execute()) {
        echo "<script>alert('OKEY, pero antes llena este formulario'); window.location.href='/conasistencia.php';</script>";
    } else {
        echo "<script>alert('Error al confirmar asistencia.'); window.location.href='es_eventos.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Estudiante no encontrado.'); window.location.href='/es_eventos.php';</script>";
}

$enlace->close();
?>
