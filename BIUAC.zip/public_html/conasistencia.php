<?php
session_start();

// Verificar si el usuario está autenticado como estudiante
if (!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true) {
    header('Location: login.html');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>BIUAC : Home</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    

    <!-- Fonts -->

    <!-- Open Sans for body font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700,800" rel="stylesheet">
	<!-- Montserrat for title -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
 
 
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Bootstrap CSS -->
  </head>
  <body>
  	
  	<!-- Start Header -->
	  <header id="mu-hero" class="" role="banner">
		<!-- Start menu  -->
		<nav class="navbar navbar-fixed-top navbar-default mu-navbar">
		  	<div class="container">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>

			      <!-- Logo -->
			      <a class="navbar-brand" href="index.html">BIUAC</a>

			    </div>

			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav mu-menu navbar-right">
                        <li><a href="index.html">Home</a></li>
                      <li><a href="index.html">Sobre nosotros</a></li>
                      <li><a href="index.html">Ponentes</a></li>
                      <li><a href="index.html">Registro</a></li>
                      <li><a href="login.html">Login</a></li>         
                      <li><a href="index.html">Contacto</a></li>
                    </ul>
              </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
      </nav>
      <!-- End menu -->

		<div class="mu-hero-overlay">
			<div class="container">
				<div class="mu-hero-area">

					<!-- Start hero featured area -->
					<div class="mu-hero-featured-area">
						<!-- Start center Logo -->
						<div class="mu-logo-area">
							<!-- text based logo -->
							<a class="mu-logo" href="#">BIUAC</a>
							<!-- image based logo -->
							<!-- <a class="mu-logo" href="#"><img src="assets/images/logo.jpg" alt="logo img"></a> -->
						</div>
						<!-- End center Logo -->

						<div class="mu-hero-featured-content">

							<h1>HELLO! WELCOME TO BIUAC</h1>
							<h2>Conoce todos los eventos que la Universidad Atunoma tiene para ti</h2>
							<p class="mu-event-date-line">2024. Barranquilla, Colombia</p>

							<div class="mu-event-counter-area">
								<div id="mu-event-counter">
									
								</div>
							</div>

						</div>
					</div>
					<!-- End hero featured area -->

				</div>
			</div>
		</div>
	</header>
	<!-- End Header -->

    		<!-- Start Register  -->
		<section id="mu-register">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-register-area">
							<div class="mu-title-area">
								<h2 class="mu-title">Completa la siguiente informacion!</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis unde, ut sapiente et voluptatum facilis consectetur incidunt provident asperiores at necessitatibus nulla sequi voluptas libero quasi explicabo veritatis minima porro.</p>
							</div>
							<div class="mu-register-content">
								<form method="post" action="php/c_asistensia.php" class="mu-register-form">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">                
												<input type="text" class="form-control" placeholder="Ingresa tu EPS" id="eps" name="eps" required>
											</div>
										</div>
                                    </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">                
                                                    <select class="form-control" style="height: 49px;" id="tipoEPS" name="tipoEPS" required>
                                                        <option selected>Tipo</option>
                                                        <option value="1">Prepagado</option>
                                                        <option value="2">Subsidiado</option>
                                                        <option value="3">Otro</option>
                                                    </select>
                                                </div>    
                                            </div>
                                        </div>
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<select class="form-control" id="tipo_participante" name="tipo_participante" required>
														<option selected disabled>Tipo de participante</option>
														<option value="1">Estudiante de pregrado</option>
														<option value="2">Estudiante de posgrado</option>
														<option value="3">Estudiante CEP</option>
														<option value="4">Docente PTC</option>
														<option value="5">Docente catedrático</option>
														<option value="6">Administrativo</option>
														<option value="7">Externo</option>
														<option value="8">Jardín infantil Mi Pequeña Uniatónoma</option>
														<option value="9">Egresado</option>
													</select>
												</div>
											</div>
										</div>
										
                                       <div class="row">
										<div class="col-md-12">
											<div class="form-group">                
												<input type="number" class="form-control" placeholder="Ingresa tu Edad" id="edad" name="edad" required>
											</div>    
										</div>
                                        </div>
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">                
												<input type="text" class="form-control" placeholder="Ingresa tu carrera" id="carrera" name="carrera" required>
											</div>    
									    </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">                
                                                <select class="form-control" style="height: 49px;" id="semestre" name="semestre" required>
                                                    <option selected>Semestre</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10">10</option>
                                                    <option value="11">Otro</option>
                                                </select>
                                            </div>    
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">                
                                                <select class="form-control" style="height: 49px;" id="genero" name="genero" required>
                                                    <option selected>Genero</option>
                                                    <option value="1">Masculino</option>
                                                    <option value="2">Femenino</option>
                                                    <option value="3">Prefiero no decirlo</option>
                                                </select>
                                            </div>    
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">                
                                                <select class="form-control" style="height: 49px;" id="equipo" name="equipo" required>
                                                    <option selected>Tienes equipo para el evento que participaras? ej: herramientas, vestimenta, etc</option>
                                                    <option value="1">Si</option>
                                                    <option value="2">No</option>
                                                </select>
                                            </div>    
                                        </div>
                                    </div>
									<div class="row">
										<div class="col-md-12">
											<button type="submit" class="mu-reg-submit-btn btn btn-primary" id="asistir" name="asistir">ASISTIR!</button>
										</div>
									</div>
								</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Register -->

    	<!-- Start footer -->
	<footer id="mu-footer" role="contentinfo">
		<div class="container">
			<div class="mu-footer-area">
				<div class="mu-footer-top">
					<div class="mu-social-media">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-youtube"></i></a>
					</div>
				</div>
				<div class="mu-footer-bottom">
					<p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="https://www.uac.edu.co/bienestar-institucional/">Bienestar institucional UAC</a>. All right reserved.</p>
				</div>
			</div>
		</div>

</footer>
<!-- End footer -->


    
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!-- Bootstrap -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Slick slider -->
<script type="text/javascript" src="assets/js/slick.min.js"></script>
<!-- Event Counter -->
<script type="text/javascript" src="assets/js/jquery.countdown.min.js"></script>
<!-- Ajax contact form  -->
<script type="text/javascript" src="assets/js/app.js"></script>

   

<!-- Custom js -->
<script type="text/javascript" src="assets/js/custom.js"></script>

<!-- Tempus Dominus Bootstrap 4 CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/css/tempusdominus-bootstrap-4.min.css" />

<!-- Tempus Dominus Bootstrap 4 JS and dependencies -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>


<!-- Template Javascript -->
<script src="js/main.js"></script>
</body>
</html>