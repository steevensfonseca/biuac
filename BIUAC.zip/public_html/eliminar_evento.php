<?php

// Habilitar la visualización de errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}


// Obtener el ID del evento desde la URL
$id = $_GET['id'];

// Eliminar el evento de la base de datos
$sql = "DELETE FROM eventos WHERE id = ?";
$stmt = $enlace->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "<script>alert('Evento eliminado con éxito'); window.location.href='eventos.php';</script>";
} else {
    echo "Error al eliminar el evento: " . $stmt->error;
}

$stmt->close();
$enlace->close();
?>
