<?php
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

if (isset($_POST['asistir'])) {
    $eps = $_POST["eps"];
    $tipoEPS = $_POST["tipoEPS"];
    $tipo_participante = $_POST["tipo_participante"];
    $edad = $_POST["edad"];
    $carrera = $_POST["carrera"];
    $semestre = $_POST["semestre"];
    $genero = $_POST["genero"];
    $equipo = $_POST["equipo"];

    $errors = [];

    // Validar que los campos no estén vacíos
    if (empty($eps)) {
        $errors[] = 'Por favor, ingrese su EPS.';
    }
    if (empty($tipoEPS) || $tipoEPS == 'Tipo') {
        $errors[] = 'Por favor, seleccione el tipo de EPS.';
    }
    if (empty($tipo_participante) || $tipo_participante == 'Tipo de participante') {
        $errors[] = 'Por favor, seleccione el tipo de EPS.';
    }
    if (empty($edad)) {
        $errors[] = 'Por favor, ingrese su edad.';
    }
    if (empty($carrera)) {
        $errors[] = 'Por favor, ingrese su carrera.';
    }
    if (empty($semestre) || $semestre == 'Semestre') {
        $errors[] = 'Por favor, seleccione su semestre.';
    }
    if (empty($genero) || $genero == 'Genero') {
        $errors[] = 'Por favor, seleccione su género.';
    }
    if (empty($equipo) || $equipo == 'Tienes equipo para el evento que participaras? ej: herramientas, vestimenta, etc') {
        $errors[] = 'Por favor, seleccione si tiene equipo.';
    }

    if (empty($errors)) {
        // Utilizar una consulta preparada para evitar SQL injection
        $insertar = "INSERT INTO estudiantes2 (eps, tipoEPS, tipo_participante, edad, carrera, semestre, genero, equipo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($enlace, $insertar);

        if ($stmt === false) {
            die('Error en la preparación de la consulta: ' . htmlspecialchars(mysqli_error($enlace)));
        }

        mysqli_stmt_bind_param($stmt, "sssissss", $eps, $tipoEPS, $tipo_participante, $edad, $carrera, $semestre, $genero, $equipo);
        $ejecutarinsertar = mysqli_stmt_execute($stmt);

        if ($ejecutarinsertar) {
            echo "<script>
                    alert('Registro exitoso');
                    window.location.href='/es_eventos.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Error en la ejecución de la consulta: " . htmlspecialchars(mysqli_stmt_error($stmt)) . "');
                    window.location.href='es_eventos.html';
                  </script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        // Mostrar errores acumulados
        $errorMsg = implode("\\n", $errors);
        echo "<script>
                alert('$errorMsg');
                window.location.href='es_eventos.html';
              </script>";
    }

    mysqli_close($enlace);
}
?>
