<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

function acceso_estudiante() {
    global $enlace;

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cedulaEstudiante = $_POST['cedulaEstudiante'];
        $contraseñaEstudiante = $_POST['contraseñaEstudiante'];

        session_start();

        // Utilizar una consulta preparada para evitar SQL injection
        $consulta = "SELECT contraseña FROM estudiantes WHERE cedula = ? AND contraseña = ?";
        $stmt = $enlace->prepare($consulta);

        if ($stmt === false) {
            die('Error en la preparación de la consulta: ' . htmlspecialchars($enlace->error));
        }

        // Vincula parámetros
        $stmt->bind_param("is", $cedulaEstudiante, $contraseñaEstudiante);

        // Ejecuta la consulta preparada
        $stmt->execute();

        // Vincula el resultado a una variable
        $stmt->bind_result($stored_password);

        // Obtiene el resultado
        $stmt->fetch();

        // Cierra la consulta preparada
        $stmt->close();

        // Verifica la contraseña
        if ($stored_password === $contraseñaEstudiante) {
            // Establecer variable de sesión para verificar inicio de sesión
            $_SESSION['student_logged_in'] = true;
            $_SESSION['cedulaEstudiante'] = $cedulaEstudiante;

            // Redirigir al estudiante a la página de eventos
            echo "<script>alert('Se ha logueado como estudiante con éxito! Bienvenido'); window.location='/es_eventos.php'</script>";
        } else {
            echo "<script>alert('El usuario/contraseña no es válido. Por favor, introduzca las credenciales correctas.'); window.location='../login.html'</script>";
            session_destroy();
        }
    }
}

acceso_estudiante();
?>
