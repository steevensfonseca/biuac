<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

if (isset($_POST['enviaAdmin'])) {
    $titulo = $_POST["titulo"];
    $lugar = $_POST["lugar"];
    $para = $_POST["para"];
    $date = $_POST["date"];
    $time = $_POST["time"];
    $descripcion = $_POST["descripcion"];
    $modalidad = $_POST["modalidad"];

    // Convertir la fecha y la hora al formato deseado
    $date_formato = date('Y-m-d', strtotime($date));
    $time_formato = date('H:i:s', strtotime($time));

    // Insertar los datos en la base de datos
    $insertar = "INSERT INTO eventos (titulo, lugar, para, fecha, hora, descripcion, modalidad) VALUES ('$titulo', '$lugar', '$para', '$date_formato', '$time_formato', '$descripcion', '$modalidad')";

    $ejecutarinsertar = mysqli_query($enlace, $insertar);

    if ($ejecutarinsertar) {
        echo "<script>alert('Evento creado exitosamente'); window.location.href='/eventos.php';</script>";
    } else {
        echo "<script>alert('Error al crear el evento. Por favor, inténtelo de nuevo.'); window.location.href='/admin.html';</script>";
    }
}
?>