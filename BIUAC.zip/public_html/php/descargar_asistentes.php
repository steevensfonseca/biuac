<?php
header("Content-Type: application/xls");
header("Content-Disposition: attachment; filename= asistencia.xls");

?>

<table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Código</th>
                    <th>Cédula</th>
                    <th>Teléfono</th>
                </tr>
            </thead>
            <tbody>
            <?php
            // Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

// Obtener ID del evento
$id_evento = $_GET['id'];

// Obtener asistentes al evento
$sql = "SELECT s.name, s.email, s.codigo, s.cedula, s.cellphone
        FROM asistencia a
        JOIN estudiantes s ON a.id_estudiante_asistencia = s.id_estudiante
        WHERE a.id_evento = ?";
$stmt = $enlace->prepare($sql);
$stmt->bind_param("i", $id_evento);
$stmt->execute();
$result = $stmt->get_result();
?>

                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['codigo']); ?></td>
                    <td><?php echo htmlspecialchars($row['cedula']); ?></td>
                    <td><?php echo htmlspecialchars($row['cellphone']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>