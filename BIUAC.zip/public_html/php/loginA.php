<?php
$servername = "localhost";
$username = "id22283185_bd";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_users";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

function acceso_administrador() {
    global $enlace;

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $usuarioAdmin = $_POST['usuarioAdmin'];
        $contraseñaAdmin = $_POST['contraseñaAdmin'];

        session_start();
        $_SESSION['usuarioAdmin'] = $usuarioAdmin;

        // Utilizar una consulta preparada para evitar SQL injection
        $consulta = "SELECT contraseñaAdmin FROM administradores WHERE usuarioAdmin = ? AND contraseñaAdmin = ?";
        $stmt = $enlace->prepare($consulta);

        if ($stmt === false) {
            die('Error en la preparación de la consulta: ' . htmlspecialchars($enlace->error));
        }

        // Vincula parámetros
        $stmt->bind_param("ss", $usuarioAdmin, $contraseñaAdmin);

        // Ejecuta la consulta preparada
        $stmt->execute();

        // Vincula el resultado a una variable
        $stmt->bind_result($stored_password);

        // Obtiene el resultado
        $stmt->fetch();

        // Cierra la consulta preparada
        $stmt->close();

        // Verifica la contraseña
        if ($stored_password === $contraseñaAdmin) {
            // Redirige al administrador a la página de administración
            echo "<script>alert('Se ha logueado como administrador con éxito! Bienvenido'); window.location='../admin.html'</script>";
        } else {
            echo "<script>alert('El usuario/contraseña no es válido. Por favor, introduzca las credenciales correctas.'); window.location='../login.html'</script>";
            session_destroy();
        }
    }
}

acceso_administrador();
?>
