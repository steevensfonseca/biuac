<?php
$servername = "localhost"; // Cambia esto si tu servidor es diferente
$username = "id22283185_bd"; // Tu usuario de MySQL
$password = "stevenTesis123."; // Tu contraseña de MySQL
$dbname = "id22283185_bd_users"; // El nombre de tu base de datos

// Crear conexión
$enlace = mysqli_connect($servername, $username, $password, $dbname);
if (!$enlace) {
    die("Database connection error: " . mysqli_connect_error());
}


if (isset($_POST['contactar'])) {
    $nameContact = $_POST["nameContact"];
    $emailContact = $_POST["emailContact"];
    $message = $_POST["message"];

    // Insertar los datos en la base de datos
    $sql = "INSERT INTO contacto (nameContact, emailContact, message) VALUES ('$nameContact', '$emailContact', '$message')";

    if (mysqli_query($enlace, $sql)) {
        // Alerta de éxito
        echo "<script>alert('Mensaje enviado con éxito.'); window.location.href='/index.html';</script>";
    } else {
        // Alerta de error
        echo "<script>alert('Error al enviar el mensaje. Por favor, inténtelo de nuevo más tarde.'); window.location.href='contacto.html';</script>";
    }
}

// Cerrar conexión
mysqli_close($enlace);
?>
