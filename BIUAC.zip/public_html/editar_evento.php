<?php
// Habilitar la visualización de errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

// Obtener el ID del evento desde la URL
$id = $_GET['id'];

// Obtener los datos del evento
$sql = "SELECT * FROM eventos WHERE id = ?";
$stmt = $enlace->prepare($sql);
if ($stmt === false) {
    die('Error en la preparación de la consulta: ' . htmlspecialchars($enlace->error));
}
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$evento = $result->fetch_assoc();
$stmt->close();

if (!$evento) {
    echo "Evento no encontrado";
    exit;
}

// Valores permitidos para el campo 'lugar'
$valores_lugar = ["UAC-Sexto piso-Bloque J", "Teatro Mario Ceballos Araujo", "Polideportivo UAC"];

// Valores permitidos para el campo 'para'
$valores_para = [
    'Ciencias Exactas', 'Arquitectura', 'Contaduría Pública', 'Arte', 'Diseño Gráfico', 'Diseño de Espacios',
    'Diseño de Modas', 'Ingeniería', 'Ingeniería Electrónica y Telecomunicaciones', 'Ingeniería Industrial',
    'Ingeniería Mecatrónica', 'Ingeniería Mecánica', 'Ingeniería de Sistemas', 'Administración y Negocios',
    'Administración Marítima y Fluvial', 'Administración de Empresas', 'Administración de Empresas Turística y Hotelera',
    'Negocios y Finanzas Internacionales', 'Tecnología en Gestión Portuaria', 'Técnica Profesional en Operaciones Portuarias',
    'Ciencias Sociales', 'Comunicación Audiovisual', 'Comunicación Social - Periodismo', 'Derecho', 'Psicología',
    'Humanidades', 'Deporte y Cultura Física', 'CUALQUIERA', 'Maestría en Administración (MBA)', 'Maestría en Educación',
    'Maestría en Ingeniería Electrónica', 'Maestría en Ingeniería Mecánica', 'Maestría en Logística Integral',
    'Maestría en Mercadeo', 'Maestría en Sistema de Gestión', 'Especialización en Alta Gerencia',
    'Especialización en Gerencia de la Comunicación para el Desarrollo Local', 'Especialización en Gestión Financiera Pública'
];

// Valores permitidos para el campo 'modalidad'
$valores_modalidad = ['Presencial', 'Virtual', 'Hibrida'];

// Actualizar los datos del evento cuando se envía el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $lugar = $_POST['lugar'];
    $para = $_POST['para'];
    $fecha = $_POST['date'];
    $hora = $_POST['time'];
    $descripcion = $_POST['descripcion'];
    $modalidad = $_POST['modalidad'];

    // Validar que los valores enviados están en las listas permitidas
    if (!in_array($lugar, $valores_lugar) || !in_array($para, $valores_para) || !in_array($modalidad, $valores_modalidad)) {
        die("Uno o más valores no son permitidos.");
    }

    $update_sql = "UPDATE eventos SET titulo = ?, lugar = ?, para = ?, fecha = ?, hora = ?, descripcion = ?, modalidad = ? WHERE id = ?";
    $update_stmt = $enlace->prepare($update_sql);
    if ($update_stmt === false) {
        die('Error en la preparación de la consulta de actualización: ' . htmlspecialchars($enlace->error));
    }
    $update_stmt->bind_param("sssssssi", $titulo, $lugar, $para, $fecha, $hora, $descripcion, $modalidad, $id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Evento actualizado con éxito'); window.location.href='eventos.php';</script>";
    } else {
        echo "Error al actualizar el evento: " . $update_stmt->error;
    }
    $update_stmt->close();
}

$enlace->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Evento</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container mt-5">
    <h1>Editar Evento</h1>
    <form method="post">
        <div class="form-group">
            <label for="titulo">Título</label>
            <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo htmlspecialchars($evento['titulo']); ?>" required>
        </div>
        <div class="form-group">
            <label for="lugar">Lugar</label>
            <select class="form-control" id="lugar" name="lugar" required>
                <?php foreach ($valores_lugar as $valor) : ?>
                    <option value="<?php echo $valor; ?>" <?php echo ($evento['lugar'] == $valor) ? 'selected' : ''; ?>><?php echo $valor; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="para">Pensado para</label>
            <select class="form-control" id="para" name="para" required>
                <?php foreach ($valores_para as $valor) : ?>
                    <option value="<?php echo $valor; ?>" <?php echo ($evento['para'] == $valor) ? 'selected' : ''; ?>><?php echo $valor; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="date">Fecha</label>
            <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($evento['fecha']); ?>" required>
        </div>
        <div class="form-group">
            <label for="time">Hora</label>
            <input type="time" class="form-control" id="time" name="time" value="<?php echo htmlspecialchars($evento['hora']); ?>" required>
        </div>
        <div class="form-group">
            <label for="descripcion">Descripción</label>
            <textarea class="form-control" id="descripcion" name="descripcion" required><?php echo htmlspecialchars($evento['descripcion']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="modalidad">Modalidad</label>
            <select class="form-control" id="modalidad" name="modalidad" required>
                <?php foreach ($valores_modalidad as $valor) : ?>
                    <option value="<?php echo $valor; ?>" <?php echo ($evento['modalidad'] == $valor) ? 'selected' : ''; ?>><?php echo $valor; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
    </form>
</div>
</body>
</html>
