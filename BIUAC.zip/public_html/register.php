<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "id22283185_eventos";
$password = "stevenTesis123.";
$dbname = "id22283185_bd_eventos";

// Crear conexión
$enlace = new mysqli($servername, $username, $password, $dbname);
if ($enlace->connect_error) {
    die("Database connection error: " . $enlace->connect_error);
}

if (isset($_POST['registrar'])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $codigo = $_POST["codigo"];
    $cedula = $_POST["cedula"];
    $cellphone = $_POST["cellphone"];
    $contraseña = $_POST["contraseña"];
    $confirm_contraseña = $_POST["confirm_contraseña"];

    // Verificar que la contraseña y la confirmación coinciden
    if ($contraseña !== $confirm_contraseña) {
        echo "<script>
                alert('Las contraseñas no coinciden');
                window.location.href='../registro.html';
              </script>";
        exit();
    }

    // Verificar si el correo es válido
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>
                alert('El correo electrónico no es válido. Por favor, introduzca una dirección de correo válida.');
                window.location.href='../registro.html';
              </script>";
        exit();
    }

    // Verificar si la cedula o el codigo ya están registrados
    $verificarQuery = "SELECT * FROM estudiantes WHERE cedula = ? OR codigo = ?";
    $stmtVerificar = mysqli_prepare($enlace, $verificarQuery);

    if ($stmtVerificar === false) {
        die('Error en la preparación de la consulta: ' . htmlspecialchars(mysqli_error($enlace)));
    }

    mysqli_stmt_bind_param($stmtVerificar, "ii", $cedula, $codigo);
    mysqli_stmt_execute($stmtVerificar);
    $result = mysqli_stmt_get_result($stmtVerificar);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>
                alert('La cédula o el código ya están registrados.');
                window.location.href='index.html';
              </script>";
        mysqli_stmt_close($stmtVerificar);
        exit();
    }

    mysqli_stmt_close($stmtVerificar);

    // Utilizar una consulta preparada para evitar SQL injection
    $insertar = "INSERT INTO estudiantes (name, email, codigo, cedula, cellphone, contraseña, confirm_contraseña) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($enlace, $insertar);

    // Verificar si la preparación de la consulta tuvo éxito
    if ($stmt === false) {
        die('Error en la preparación de la consulta: ' . htmlspecialchars(mysqli_error($enlace)));
    }

    // Vincular parámetros: s = string, i = integer
    mysqli_stmt_bind_param($stmt, "ssiisss", $name, $email, $codigo, $cedula, $cellphone, $contraseña, $confirm_contraseña);

    // Ejecutar la consulta preparada
    $ejecutarinsertar = mysqli_stmt_execute($stmt);

    // Verificar el resultado
    if ($ejecutarinsertar) {
        echo "<script>
                alert('Registro exitoso');
                window.location.href='login.html';
              </script>";
    } else {
        echo "Error en la ejecución de la consulta: " . htmlspecialchars(mysqli_stmt_error($stmt));
    }

    // Cerrar la declaración
    mysqli_stmt_close($stmt);
}

// Cerrar conexión
mysqli_close($enlace);
?>
