// utilidades.js

/*
// Función para enviar el formulario mediante AJAX
export function enviarFormulario() {
    console.log('Enviando formulario...'); // Mensaje de depuración
    console.log('Datos a enviar:', $('#miFormulario').serialize()); // Imprimir datos a enviar

    $.ajax({
        url: './php/freeTrading.php', // Script PHP para procesar y guardar datos
        type: 'POST',
        data: $('#miFormulario').serialize(), // Serializar el formulario
        success: function(response) {
            console.log('Respuesta del servidor:', response); // Mensaje de depuración
            cargarTabla(); // Actualizar la tabla después de guardar los datos
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('Error en la solicitud AJAX:', textStatus, errorThrown); // Mensaje de error
            console.log('Detalles completos:', jqXHR); // Imprimir detalles completos
        }
    });
}
*/
// Función para cargar los datos en la tabla
export function cargarTabla() {
    $.ajax({
        url: 'php/tabla.php', // Script PHP para obtener datos de la base de datos
        type: 'GET',
        success: function(data) {
            $('#miTabla tbody').html(data); // Actualizar el contenido del tbody
        }
    });
}
