// main.js
import {cargarTabla } from './utilidades.js';

document.addEventListener("DOMContentLoaded", function () {

    // Resto del código que usa jQuery
    cargarTabla();
    
    $('#miFormulario').submit(function(event) {
        event.preventDefault();
        enviarFormulario();
    });
});
